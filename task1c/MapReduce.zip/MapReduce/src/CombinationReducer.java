import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CombinationReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

	// emmited 2-letter characters are counted and outputted
	@Override
	public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
		int sum = 0;
		Iterator<IntWritable> i = values.iterator();
		while (i.hasNext()){
			sum+=i.next().get();

		}
		context.write(key,new IntWritable(sum));
	}
}