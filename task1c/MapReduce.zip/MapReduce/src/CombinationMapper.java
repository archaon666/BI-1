import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CombinationMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	
	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();
	
	// for each word longer than 1 character, all 2-letter combinations are emmited
	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String line = value.toString();
		StringTokenizer tokenizer = new StringTokenizer(line);

		while (tokenizer.hasMoreTokens()){
			String curr = tokenizer.nextToken();
			for (int i = 0; i< curr.length()-1;++i){
				if (Character.isLetter(curr.charAt(i)) && Character.isLetter(curr.charAt(i+1))){
					word.set(curr.substring(i, i+2).toLowerCase());
					context.write(word, one);
				}
			}
		}

	}
}
