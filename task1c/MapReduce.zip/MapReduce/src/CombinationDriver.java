import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;



public class CombinationDriver {

	public static void main(String[] args) throws Exception {
		// runs two separate jobs
		// first job counts the combinations
		
		Configuration conf = new Configuration();

		Job job = new Job(conf, "combinationcount");

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		job.setMapperClass(CombinationMapper.class);
		job.setReducerClass(CombinationReducer.class);



		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path("temp"));


		boolean success = job.waitForCompletion(true);
		if (success==false) System.exit(1);
		
		// second job sorts the result
		
		Configuration confSort = new Configuration();
		Job jobSort = new Job (confSort, "combinationsort");

		jobSort.setOutputKeyClass(IntWritable.class);
		jobSort.setOutputValueClass(Text.class);

		jobSort.setMapperClass(SortMapper.class);
		jobSort.setReducerClass(SortReducer.class);

		jobSort.setInputFormatClass(TextInputFormat.class);
		jobSort.setOutputFormatClass(TextOutputFormat.class);

		jobSort.setSortComparatorClass(SortComparator.class);

		FileInputFormat.addInputPath(jobSort, new Path("temp"));
		FileOutputFormat.setOutputPath(jobSort, new Path(args[1]));

		success = jobSort.waitForCompletion(true);
		System.exit(success ? 0 : 1);
	}
}

