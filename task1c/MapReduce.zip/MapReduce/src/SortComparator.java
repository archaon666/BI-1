import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.WritableComparable;

import org.apache.hadoop.io.WritableComparator;


public class SortComparator extends WritableComparator {

	protected SortComparator() {
		super(IntWritable.class, true);
		
	}
	
	// this is a comparator that sorts in descending order
	@Override
	public int compare(WritableComparable w1, WritableComparable w2) {
	 
	IntWritable key1 = (IntWritable) w1;
	IntWritable key2 = (IntWritable) w2;
	 
	if (key1.get()>key2.get()) return -1;
	else if (key1.get() == key2.get()) return 0;
	else return 1;
	
	}


}
