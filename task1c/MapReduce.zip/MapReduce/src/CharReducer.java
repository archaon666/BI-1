import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CharReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

	@Override
	public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
		int sum = 0;
		Iterator<IntWritable> i = values.iterator();

		while (i.hasNext()){
			sum+=i.next().get();	
		}

		//sums all the frequencies (expected to be 1) and outputs the result
		context.write(key,new IntWritable(sum));


	}
}