import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class SortReducer extends Reducer<IntWritable, Text, Text, IntWritable> {

	// outputs the combinations sorted by frequencies. Default uses ascending sort
	@Override
  	public void reduce(IntWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		
		Iterator<Text> i = values.iterator();
		while (i.hasNext())
			context.write(new Text(i.next()),key);

  	}
}