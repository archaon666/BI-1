import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SortMapper extends Mapper<LongWritable, Text, IntWritable, Text> {
	
	// takes all the data and emits for each frequency all the 2-letter combinations
	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String line = value.toString();
		StringTokenizer tokenizer = new StringTokenizer(line);
		
	  	while (tokenizer.hasMoreTokens()){
	  		String text = tokenizer.nextToken();
	  		String freq = tokenizer.nextToken();
	  		IntWritable freqInt = new IntWritable(Integer.parseInt(freq));
	  		context.write( freqInt, new Text(text));
		  
	  		
	  	}
	  
	}
}
