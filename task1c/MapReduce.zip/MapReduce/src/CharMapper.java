import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CharMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	
	private final static IntWritable one = new IntWritable(1);
	private Text letter = new Text();
	
	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String line = value.toString();
		char [] chars = line.toCharArray();
		for (int i = 0; i < chars.length;++i){
			if (Character.isLetter(chars[i])){
				letter.set(String.valueOf(Character.toLowerCase(chars[i])));
				
				//outputs the letter with frequency 1
				context.write(letter, one);

			}
		}

	}
}
